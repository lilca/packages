/* opt_strcat.h */
#ifndef	OPT_STRCAT_H
#define	OPT_STRCAT_H

void opt_strcat(char* base, char* tar);

#endif